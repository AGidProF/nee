/*
===========================================================================================================

Thanks for Using Our Source AntiDoS
first you must know basic from this sources code before edited!
you can edit the username + password in config.json
but if you already build thats, you cant change the username and password anymore (need build again)

- This Sources Also Supported for SA:MP (Beta)
use main port 7777 if you're SA:MP
use main port 17091 if you're GTPS

thanks to :
- MGC
- MGV
- GrowTopiaNoobs
- ZxBoy
- iMix

This Source has 1000 lines!!
===========================================================================================================
*/
const helpers7777 = require('./helpers');
const PermiumCheck1 = "No"
const PremiumCheckTrue = "Yes"
// requirements
const fs = require('fs');
const readline = require('readline');
// end of Basic
const colors = require('colors');
// const { TextInput } = require('./TextInput');
// const { 7z, 7zIT } = require('./7z');
// const { Materials, MT } = require('./materials')
const { Usernames, Passwords } = require('./config.json');
//const got = require('got');
const stringOne = 'This is a plain string.';
const stringTwo = 'This string is red.'.red;
const stringThree = 'This string is blue.'.blue;
const today = new Date().toLocaleDateString(); 
// Requirements for HTTP
const { BLANKING } = require('./dns_checker.js');
const HTTPS11 = require('./ip_setup.json');
// var
var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
// end
const choose = `
=======================================================================================================

██████╗██╗  ██╗ ██████╗  ██████╗ ███████╗███████╗
██╔════╝██║  ██║██╔═══██╗██╔═══██╗██╔════╝██╔════╝
██║     ███████║██║   ██║██║   ██║███████╗█████╗  
██║     ██╔══██║██║   ██║██║   ██║╚════██║██╔══╝  
╚██████╗██║  ██║╚██████╔╝╚██████╔╝███████║███████╗
 ╚═════╝╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
                                                  
=======================================================================================================
`
const listen = `
=======================================================================================================

██╗     ██╗███████╗████████╗███████╗███╗   ██╗██╗███╗   ██╗ ██████╗ 
██║     ██║██╔════╝╚══██╔══╝██╔════╝████╗  ██║██║████╗  ██║██╔════╝ 
██║     ██║███████╗   ██║   █████╗  ██╔██╗ ██║██║██╔██╗ ██║██║  ███╗
██║     ██║╚════██║   ██║   ██╔══╝  ██║╚██╗██║██║██║╚██╗██║██║   ██║
███████╗██║███████║   ██║   ███████╗██║ ╚████║██║██║ ╚████║╚██████╔╝
╚══════╝╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝ ╚═════╝ 
                                                                    
=======================================================================================================

`
const Frenzy = `
=======================================================================================================


███████╗██████╗ ███████╗███╗   ██╗███████╗██╗   ██╗███████╗ ██████╗ 
██╔════╝██╔══██╗██╔════╝████╗  ██║╚══███╔╝╚██╗ ██╔╝██╔════╝██╔════╝ 
█████╗  ██████╔╝█████╗  ██╔██╗ ██║  ███╔╝  ╚████╔╝ ███████╗██║  ███╗
██╔══╝  ██╔══██╗██╔══╝  ██║╚██╗██║ ███╔╝    ╚██╔╝  ╚════██║██║   ██║
██║     ██║  ██║███████╗██║ ╚████║███████╗   ██║   ███████║╚██████╔╝
╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ 
                                                                    
=======================================================================================================
`
const welcomes = `
=======================================================================================================

█     █░▓█████  ██▓     ▄████▄   ▒█████   ███▄ ▄███▓▓█████ 
▓█░ █ ░█░▓█   ▀ ▓██▒    ▒██▀ ▀█  ▒██▒  ██▒▓██▒▀█▀ ██▒▓█   ▀ 
▒█░ █ ░█ ▒███   ▒██░    ▒▓█    ▄ ▒██░  ██▒▓██    ▓██░▒███   
░█░ █ ░█ ▒▓█  ▄ ▒██░    ▒▓▓▄ ▄██▒▒██   ██░▒██    ▒██ ▒▓█  ▄ 
░░██▒██▓ ░▒████▒░██████▒▒ ▓███▀ ░░ ████▓▒░▒██▒   ░██▒░▒████▒
░ ▓░▒ ▒  ░░ ▒░ ░░ ▒░▓  ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░   ░  ░░░ ▒░ ░
  ▒ ░ ░   ░ ░  ░░ ░ ▒  ░  ░  ▒     ░ ▒ ▒░ ░  ░      ░ ░ ░  ░
  ░   ░     ░     ░ ░   ░        ░ ░ ░ ▒  ░      ░      ░   
    ░       ░  ░    ░  ░░ ░          ░ ░         ░      ░  ░
                        ░                                   
=======================================================================================================
`
const empty = `
=======================================================================================================

███████╗███╗   ███╗██████╗ ████████╗██╗   ██╗
██╔════╝████╗ ████║██╔══██╗╚══██╔══╝╚██╗ ██╔╝
█████╗  ██╔████╔██║██████╔╝   ██║    ╚████╔╝ 
██╔══╝  ██║╚██╔╝██║██╔═══╝    ██║     ╚██╔╝  
███████╗██║ ╚═╝ ██║██║        ██║      ██║   
╚══════╝╚═╝     ╚═╝╚═╝        ╚═╝      ╚═╝   
                                             
=======================================================================================================

`

const setup = `
=======================================================================================================

███████╗███████╗████████╗██╗   ██╗██████╗ 
██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗
███████╗█████╗     ██║   ██║   ██║██████╔╝
╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝ 
███████║███████╗   ██║   ╚██████╔╝██║     
╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝     
                                          
=======================================================================================================

`
console.log(Frenzy.yellow)
console.log(`
Instagram : frenzy.666
Saweria : saweria.co/FrenzyS6
Choose by number || Pilih dengan angka
Listed :
============================== PUBLIC & OPEN SOURCES ==============================

[1] AntiDDOS
[2] Version Check
[3] Creator Info
[4] Github Links
[5] About This Tools
[6] Websites Ip Check
[7] Base64 Dec / Enc
[8] Discord Rich Presence (Tutorial in Github)
[9] Vps IP Info
[10] Growtopia Server Data Reader (Thanks to Galvin)
[11] Ip Checker (Thanks to Galvin)
[12] Features Creator
[13] Discord Account Nuker (By MRX-0101)
[14] File Makers
[15] Discord Token Info (bit.ly/guckproject)
[16] Instagram Scrapper (By SadesXD)
[17] AntiDDOS By HasanH6 (FIXED!)
[18] GrowTopia Discord Rich Presence (by AykutSarac)
[19] HTTP Test

======================================== END ========================================
`.green)
//STARTED CODING !!
console.log("If PREMIUM type LETTER if PUBLIC type NUMBER".green)
rl.question("What You Want to Do in Here? : ", NanyaDulu => {
    if(NanyaDulu == "5") {
        console.log("This Anti DDOS Created by FrenzySG for Publics!");
        const keypress = async () => {
            process.stdin.setRawMode(true)
            return new Promise(resolve => process.stdin.once('data', () => {
              process.stdin.setRawMode(false)
              resolve()
            }))
          }
          
          ;(async () => {
          
            console.log('Any Key To Exits')
            await keypress()
          })().then(process.exit)
      } else {
        if(NanyaDulu == "19") {
          var http = require('http');

//create a server object:
http.createServer(function (req, res) {
  res.write('Hello World!'); //write a response to the client
  res.end(); //end the response
}).listen(8080); //the server object listens on port 8080
        } else {
  // PREMIUM KEY (BETA) UNDER PROGRESS!
	      // STILL BUG MEMEK ANJING LU SEMUA KENTOT
      if(NanyaDulu == "A") {
        console.log("Not Premiums!".red)
        const keypress = async () => {
          process.stdin.setRawMode(true)
          return new Promise(resolve => process.stdin.once('data', () => {
            process.stdin.setRawMode(false)
            resolve()
          }))
        }
        
        ;(async () => {
        
          console.log('Any Key To Exits')
          await keypress()
        })().then(process.exit)
      } else {
        if(NanyaDulu == "B") {
          console.log("Not Premiums!".red)
          const keypress = async () => {
            process.stdin.setRawMode(true)
            return new Promise(resolve => process.stdin.once('data', () => {
              process.stdin.setRawMode(false)
              resolve()
            }))
          }
          
          ;(async () => {
          
            console.log('Any Key To Exits')
            await keypress()
          })().then(process.exit)
        } else {
          if(NanyaDulu == "C") {
            console.log("Not Premiums!".red)
            const keypress = async () => {
              process.stdin.setRawMode(true)
              return new Promise(resolve => process.stdin.once('data', () => {
                process.stdin.setRawMode(false)
                resolve()
              }))
            }
            
            ;(async () => {
            
              console.log('Any Key To Exits')
              await keypress()
            })().then(process.exit)
          } else {
            if(NanyaDulu == "D") {
              console.log("Not Premiums!".red)
              const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('Any Key To Exits')
                await keypress()
              })().then(process.exit)
            } else {
              if(NanyaDulu == "E") {
                console.log("Not Premiums!".red)
                const keypress = async () => {
                  process.stdin.setRawMode(true)
                  return new Promise(resolve => process.stdin.once('data', () => {
                    process.stdin.setRawMode(false)
                    resolve()
                  }))
                }
                
                ;(async () => {
                
                  console.log('Any Key To Exits')
                  await keypress()
                })().then(process.exit)
              } else {
                if(NanyaDulu == "F") {
                  console.log("Not Premiums!".red)
                  const keypress = async () => {
                    process.stdin.setRawMode(true)
                    return new Promise(resolve => process.stdin.once('data', () => {
                      process.stdin.setRawMode(false)
                      resolve()
                    }))
                  }
                  
                  ;(async () => {
                  
                    console.log('Any Key To Exits')
                    await keypress()
                  })().then(process.exit)
                } else { 
                  if(NanyaDulu == "17") { // HasanH6 HTTPS Kinda SUS But its okey...
                    const readline = require("readline");
const http = require("restana")();
const httpz = require('http');
const prompt = require('prompt-sync')();
const { RateLimiterMemory } = require('rate-limiter-flexible');
const fs = require('fs');
const colors = require('colors');
const parse = require('html-parser').parse;
const needle = require('needle');
const net = require('net');

let norlog = false
let terminalmode = false


if(!fs.existsSync('./gtps.html')) {
fs.writeFile('gtps.html', 'welcome to our website', function (err) {
if (err) return console.log(err);
});
}
const rateLimiter = new RateLimiterMemory({
points: 5, // 5 points
duration: 1 // per second
});
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
if(!fs.existsSync('./Http.json')) {
var myJson = {
	'website': false,
	'blacklist': ['192.0.0.1'],
	'saveip':  '',
	'saveport':  '',
	'savedconnection': false
};
fs.writeFileSync('./Http.json', JSON.stringify(myJson));
}
if(!fs.existsSync('./logs.txt')) {
fs.writeFile('logs.txt', '', function (err) {
if (err) return console.log(err);
});
}
var data = JSON.parse(fs.readFileSync('./Http.json'));
var blacklist = data.blacklist
var website = data.website
var savedconnection = data.savedconnection
var saveip = data.saveip
var saveport = data.saveport
console.log(`
|---------------------------------------------------------|
|Welcome GTPS HTTP.                                       |
|This HTTP Made By HasanH6#1068                           |
|Hyper Text Transfer Protocol For GTPS, TCP Packets.      |
|you can type terminal to open the terminal!              |
|---------------------------------------------------------|
`);
if (data.savedconnection == true){
var cnc = prompt('do you want to log with your recent logs?[y] or you want to clear it?[n] : ')
if (cnc == 'terminal'){
terminal();
terminalmode = true;
console.log(`
welcome to terminal, your now in terminal mode, type help.
`);
return;
}
if (cnc == 'y' || cnc == ''){
var saveip = data.saveip
var ip = saveip
var port = data.saveport
norlog = true
}else if (cnc == 'n'){
norlog = false
data.savedconnection = false;
data.saveip = '';
data.saveport = '';
fs.writeFileSync('./Http.json', JSON.stringify(data));
}else {
console.log('error');
return;
}
}
if (norlog == false){
var ip = prompt('Please put your server ip: ');
if(ip == 'terminal'){
terminal();
terminalmode = true;
console.log(`
welcome to terminal, your now in terminal mode, type help.
`);
return;
}
if (ip == ''){
var ip = '127.0.0.1';
console.log('your logged ip is : ' + ip)
}

var port = prompt('please put the port: ');
if(port == ''){
var port = 80;
console.log('your logged port is : ' + port);
}
if(data.savedconnection == false){
var changes = prompt('do you want to save the current ip for next time?(y/n):');
if (changes == 'y' || changes == ''){
savedconnection = true;
data.savedconnection = true;
data.saveip = ip;
data.saveport = port;
saveip = data.saveip
saveport = data.saveport
fs.writeFileSync('./Http.json', JSON.stringify(data));
}
}
}

function define(req,res){
var clientipx = req.headers['x-forwarded-for'] || 
req.connection.remoteAddress || 
req.socket.remoteAddress ||
req.connection.socket.remoteAddress;
if (clientipx.substr(0, 7) == "::ffff:") {
clientip = clientipx.substr(7)
}
}
var timeout1 = true;
var timeout2 = true;
var timeout3 = true;
function anti(){
//dos using get packet
http.get("/" + ip, function(req, res) {
define(req,res)
if(timeout1 == false){
return;
}
setTimeout(function () {
timeout1 = true;
}, 3000);
timeout1 = false;
var dat1 = 'the client ' + clientip + ' have sent GET packet to /' + ip + ' (this may be a dos)\n'
fs.appendFile('logs.txt', dat1, function (err) {
});
req.connection.destroy();
return;
});

//dos using head packet
http.head("/" + ip, function(req, res) {
define(req,res)
if(timeout2 == false){
return;
}
setTimeout(function () {
timeout2 = true;
}, 3000);
timeout2 = false
var dat2 = 'the client ' + clientip + ' have sent HEAD packet to /' + ip + ' (this may be a dos)\n'
fs.appendFile('logs.txt', dat2, function (err) {
});
req.connection.destroy();
return;
});

//dos using post packet
http.post("/" + ip, function(req, res) {
define(req,res)
if(timeout3 == false){
return;
}
setTimeout(function () {
timeout3 = true;
}, 3000);
timeout3 = false
var dat3 = 'the client ' + clientip + ' have sent POST packet to /' + ip + ' (this may be a dos)\n'
fs.appendFile('logs.txt', dat3, function (err) {
});
req.connection.destroy();
return;
});
}

 

var time = true
var time1 = true
async function CreateWebServer() {
rateLimiter.consume(5) // consume 1 point per event
.then(() => {
var data = JSON.parse(fs.readFileSync('./Http.json'));
http.post("/growtopia/server_data.php", function(req, res) {
define(req,res)
if(time == false){
return;
}
setTimeout(function () {
time = true;
}, 1500);
time = false
if(blacklist.includes(clientip)){
let data1 = 'the black listed ip ' + clientip + ' just send POST packet to /growtopia/server_data.php and fails\n'
fs.appendFile('logs.txt', data1, function (err) {
console.log(err);
});
res.writeHead(505)
return;
}
res.send(`server|` + ip + `\nport|17091\ntype|1\n#maint|Growtopia\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001`)
var data2 = 'the client ' + clientip + ' just sent a post packet to /growtopia/server_data.php\n'
fs.appendFile('logs.txt', data2, function (err) {
});
})

//anti
anti();


//website here
http.get("/", function(req, res) {
define(req,res)
if(time1 == false){
return;
}
setTimeout(function () {
time1 = true;
}, 1000);
time1 = false
var data = JSON.parse(fs.readFileSync('./Http.json'));
if(blacklist.includes(clientip)){
var data3 = 'the black listed ip ' + clientip + ' just send GET packet to http://' + ip + '/ and fails\n'
fs.appendFile('logs.txt', data3, function (err) {
});
res.writeHead(505)
return;
}
if(data.website != false){
res.writeHead(200, { 'Content-Type': 'text/html'})
 fs.readFile('gtps.html', function(error, data){
res.write(data)
var data4 = 'the client ' + clientip + ' just sent a GET packet to http://' + ip + '/\n'
fs.appendFile('logs.txt', data4, function (err) {
});
res.end()
})
}else {
var data5 = 'the client ' + clientip + ' just sent GET packet, got connection time out since website is disabled\n'
fs.appendFile('logs.txt', data5, function (err) {
});
res.writeHead(404)
}
});
});
await http.start(port);
}
CreateWebServer()
terminal()
console.log("you can type 'help' down below to get help for commands");
console.log('okay the http is running on ' + ip + ':' + port + ', Logs will be shown below:')



function terminal(){
console.clear()
var recursiveAsyncReadLine = function () {
rl.question('', function (answer) {
if(answer == 'help' || answer == 'website' || answer == '' ||answer == 'http2' || answer.includes('block ') || answer.includes('unblock') || answer == 'blacklist' || answer == 'clear'){
if(answer == 'help'){
console.log(`
HTTP Commands Help:
|------------------------------------------------------------|
|-website - enables/disables web at http://ip/               |
|-blacklist - check black listed ips                         |
|-block (ip) - Blacklist an ip from the HTTP                 |
|-unblock (ip) - remove ip from blacklist of the HTTP        |
|-http2 - enter another safe mode http                       |
|-dos - Dos Mode                                             |
|------------------------------------------------------------|
`);
}
if(answer == 'http2'){
if(terminalmode == true){
httpv2();
return;
}else {
console.log("please make sure to open terminal and enter httpv2 to open http version 2");
}
}
if(answer == 'website'){
var data = JSON.parse(fs.readFileSync('./Http.json'));
if(data.website == true){
website = false;
data.website = false; 
fs.writeFileSync('./Http.json', JSON.stringify(data));
console.log('The Website has Been disabled and it will be connection timed out for all clients!');    
}else {
var data = JSON.parse(fs.readFileSync('./Http.json'));
data.website = true; 
fs.writeFileSync('./Http.json', JSON.stringify(data));
website = true;
console.log('Website has been enabled you can check at http://'+ ip + '/ and you can disable it by executing the command again.');
}
}
if(answer.includes('unblock ')){
const asw = 'unblock ';
const commandBody = answer.slice(asw.length);
const args = commandBody.split(' ');
const y = args[0]
if(blacklist.includes(y)){
var data = JSON.parse(fs.readFileSync('./Http.json'));
const index = data.blacklist.indexOf(y);
if (index > -1) {
  data.blacklist.splice(index, 1);
}
fs.writeFileSync('./Http.json', JSON.stringify(data));
console.log('you have removed the ip ' + y + ' from the blacklist');
return recursiveAsyncReadLine();
}else {	
console.log('Sorry the ip ' + y + ' is not blacklisted!');
return recursiveAsyncReadLine();
}
}
if(answer.includes('block ')){
const asw = 'block ';
const commandBody = answer.slice(asw.length);
const args = commandBody.split(' ');
const y = args[0]
if(blacklist.includes(y)){
console.log('The ip ' + args + ' is already in the blacklist!');
return recursiveAsyncReadLine();
}else{
blacklist.push(y);
var data = JSON.parse(fs.readFileSync('./Http.json'));
data.blacklist.push(y);
fs.writeFileSync('./Http.json', JSON.stringify(data));
console.log('you have added the ip ' + y + ' to the Black list!');
}
}
if(answer == 'blacklist'){
console.log(blacklist + ' in the black list!');
}
if(answer == 'clear'){
console.clear();
}
recursiveAsyncReadLine();
}else {
console.log("sorry '" + answer + "' is not recognized as an internal or external command");
recursiveAsyncReadLine()
}
});
}
recursiveAsyncReadLine();
}
function httpv2(){
if (terminalmode == false){
console.log('please enter terminal mode to enter httpv2');
return;
}
var timexout = true
var timexout1 = true
var timexout2 = true
console.log(`
|---------------------------------------------------------|
|Http Version 2(tcp packets)                              |
|made by HasanH6#1068                                     |                         
|---------------------------------------------------------|
`);
var ips = prompt('put server ip: ');
var ports = prompt('put server port: ');
var server = httpz.createServer(function (req, res) {
if (req.url == "/growtopia/server_data.php") {
define(req,res);
if(req.method === "POST") {
if(timexout == false){
req.connection.destroy();
return;
}
setTimeout(function () {
timexout = true;
}, 1000);
timexout = false
res.write('server|' + ips + '\nport|17091\ntype|1\n#maint|Maintenance\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001');
var dns0 = '[HTTP2-logs]the client ' + clientip + ' sent POST packet to /growtopia/server_data.php\n'
fs.appendFile('logs.txt', dns0, function (err) {
});
res.end();
}else{

if(timexout1 == false){
req.connection.destroy();
return;
}
setTimeout(function () {
timexout1 = true;
}, 3000);
timexout1 = false

define(req,res);	
var dns1 = '[HTTP2-logs]the client ' + clientip + ' have sent ' + req.method + ' PACKET so got timed out\n'
fs.appendFile('logs.txt', dns1, function (err) {
});
req.connection.destroy();
}

}else {
	
if(timexout2 == false){
req.connection.destroy();
return;
}
setTimeout(function () {
timexout2 = true;
}, 3000);
timexout2 = false	


define(req,res);
var dns2 = '[HTTP2-logs]the client ' + clientip + ' have sented packet to ' + req.url + ' so gets blocked\n'
fs.appendFile('logs.txt', dns2, function (err) {
});
req.connection.destroy();
}	
});
server.listen(ports);
console.log('Http v2 is running on ' + ips + ':' + ports + ' logs will be pasted at logs.txt');
}
                  } else {
      if(NanyaDulu == "16") { // ig scrapper by SadesXD (STILL BUG ANJING BANGSAT MMK LONTE)
        console.log("Example : frenzy.666");
        rl.question("Whats is the instagram do you want to scrap? : ", UserIG => {
          const ig = require("instagram-scrapper")
ig(UserIG).then(response => {
    console.log(response);
}).catch(error => {
    console.log("We get some error!");
})
        })
      } else {
      if(NanyaDulu == "15") { // discord token checker from bit.ly/guckproject via Galvin
        const fetch = require('node-fetch')
const read = require('read')
console.log(`Token Information reader in NodeJS`)
read({ prompt: 'Discord Token: ', silent: false }, function(er, DiscordToken) {
console.clear();
fetch(`https://discord.com/api/v6/users/@me`, {
                            headers: {
                                "authorization": DiscordToken
                            }
}).then(resp => resp.json()).then(response => {
                            if (response.id) {
                                if(!response.premium_type) {
                                    nitro = "Nitro"
                                } else {
                                    if(response.premium_type === 1) { nitro = "Nitro Classic"}
                                    if(response.premium_type === 2) { nitro = "Nitro Gaming"}
                                }
                                send(DiscordToken, response.id, response.username, response.discriminator, response.email, response.phone, nitro)
                            }
                        })
function send(token, id, username, tag, email, phone, nitro, avatar) {
    if (email === null) {
    }
    if (phone === null) {    
    }
    console.log(`Discord token${token}\n\nDiscord ID: ${id}\n\nDiscord TAG: ${username}#${tag}\n\nDiscord Email: ${email}\n\nDiscord Phone: ${phone}`)
}
})
      } else {
      if(NanyaDulu == "14") {
        rl.question("What is the files name? : ", NamaFileDie => {
          rl.question("What is the files format? (just write example : txt)", Formatnye => {
            rl.question(`What is the text in ${NamaFileDie}.${Formatnye} ? : `, IsiText => {
console.log(`

Comfirm System :
Files name : ${NamaFileDie}
Formats : ${Formatnye}
Results : ${NamaFileDie}.${Formatnye}
Text in files : ${IsiText}

Type Y to confirm N to cancel
`)
rl.question("Are You Sure? : ", NanyaBentar => {
  if(NanyaBentar == "Y") {
    fs.writeFileSync(
      `${NamaFileDie}.${Formatnye}`,
      `${IsiText}`
    );
    console.log(`${NamaFileDie}.${Formatnye} has been created!`)
    process.exit();
  } else {
    if(NanyaBentar == "N") {
      console.log("Cancelled")
      process.exit();
    }
  }
})
            })
          })
        })
      } else {
      if(NanyaDulu == "12") {
        console.log(`
        
Features Creator :
ServerData Reader (Galvin)
IP Checker (Galvin)
Discord RPC Custom (FrenzySG, iMix)
Websites IP Check (Scooopy, TomatoDev)
VPS Ip Info (FrenzySG)
AntiDoS (FrenzySG)
Discord Account Nuker (MRX-0101)

        `)
      } else {
        if(NanyaDulu == "13") { // by MRX
          const { Color } = require('./src/Design');
const { User } = require('./src/User');
const Readline = require('readline').createInterface(
  { input: process.stdin, output: process.stdout }
);

const init = () => {
  console.clear();
  console.log(Color.banner);
  process.stdout.write(
    String.fromCharCode(27) + "]0;" + 'MRX' + String.fromCharCode(7)
  );
  
  Color.options.forEach(
    option => {
      Color.log(option, Color.options.indexOf(option) + 1);
    }
  );
  console.log("Choose by Number");
  Readline.question(Color.list[1].code + '  WHICH ONE DO YOU WANNA EXECUTE? > ', option => {
    if (!['1', '2'].includes(option)) return init();

    Readline.question(Color.list[1].code + '  TOKEN >> ', token => {
      const user = new User(
        { token: token }
      );

      if (option == '1') {
        Color.log('Nuking.');

        user.nuke().catch(
          (e) => {
            Color.log(e);

            setTimeout(() => {
              init();
            }, 1000);
          }
        );
      } else if (option == '2') {
        user.info().then(
          data => {
            console.clear();
            console.log(Color.banner);

            data.forEach((d) => Color.log(d));
            setTimeout(process.exit, 60000);
          }
        ).catch(
          (e) => {
            Color.log(e);

            setTimeout(() => {
              init();
            }, 1000);
          }
        );
      };
    });
  });
};

init();
        } else {
          if(NanyaDulu == "18") { // GT RPC BY Phemus
            console.log("You Will Runned to Growtopia if You Active this features")
            rl.question("Are You Sure? (Y/N) : ", BentarTanyaDlu => {
              if(BentarTanyaDlu == "Y") {
                const app = require('./src/bundle');
const rpc = require("discord-rpc");
const _cp = require('child_process');
const { ErrorHandler } = require('./src/lib/functionFactory');
process.title = app.processTitle;

rpc.register(app.AppID);

const client = new rpc.Client({
    transport: 'ipc'
});

client.on('ready', () => {
    
    //  Run Growtopia.exe
    _cp.execFile(app.dataPath + 'Growtopia.exe').on('close', (e) => {
        process.exit(0);
    });


    console.log('Growtopia Presence is running now!\nMade by Phemus --> https://github.com/AykutSarac/Growtopia-RPC');
    app.versionCheck().then(data => console.log("\n" + data));

    //  Create timestamp
    const now = new Date();

    setInterval(() => {

        app.data().then(data => {
            client.setActivity({
                details: "GrowID: " + data.growid,
                state: "In World: " + data.world,
                largeImageKey: "1_grow_icon_1513191167",
                largeImageText: "Growtopia",
                startTimestamp: now
            }).catch(e => {
                ErrorHandler(e);
            });
        }).catch(e => {
            ErrorHandler(e);
        });
    }, 3000);
});


// Make Connection with API
client.login({
    clientId: app.AppID
}).catch(() => {
    console.log("Couldn't make connection. If discord is not running, start discord and run the Growtopia-RPC again.");
});
              } else {
                if(BentarTanyaDlu == "N") {
                  console.log("Cancelled")
                  const keypress = async () => {
                    process.stdin.setRawMode(true)
                    return new Promise(resolve => process.stdin.once('data', () => {
                      process.stdin.setRawMode(false)
                      resolve()
                    }))
                  }
                  
                  ;(async () => {
                  
                    console.log('Any Key To Exits')
                    await keypress()
                  })().then(process.exit)
                }
              }
            })
          } else {
      if(NanyaDulu == "9") { // API created by ipinfo.io
        rl.question("Enter the Targets IP : ", IPTarget => {
          if(IPTarget == "") {
            console.log("Cannot Blank")
          } else {
            var http = require('http');

//The url we want is: 'www.random.org/integers/?num=1&min=1&max=10&col=1&base=10&format=plain&rnd=new'
var options = {
  host: 'ipinfo.io',
  path: "/"+IPTarget+"?token=b9df36a2a87f8c"
};
callback = function(response) {
  var str = '';
  //another chunk of data has been received, so append it to `str`
  response.on('data', function (chunk) {
    str += chunk;
  });
  //the whole response has been received, so we just print it out here
  response.on('end', function () {
    console.log(str);
  });
}
http.request(options, callback).end();
          }
        })
      } else {
        if(NanyaDulu == "11") { // IP CHECKER By @Galvin
          let request = require('request');
          console.log('Simple IP Checker')
          rl.question('IP : ', ip => {
              if (!ip) {
                  return console.log(`please put the ip you want to check`)
              } else {
                console.log("Bentar...")
                  request.get(`https://ipapi.co/${ip}/region`, function(err, response, region) {
                      request.get(`https://ipapi.co/${ip}/timezone`, function(err, response, timezone) {
                          request.get(`https://ipapi.co/${ip}/currency`, function(err, response, currency) {
                              request.get(`https://ipapi.co/${ip}/country_name`, function(err, response, country) {
                                  request.get(`https://ipapi.co/${ip}/country_calling_code`, function(err, response, country_code) {
                                      request.get(`https://ipapi.co/${ip}/version`, function(err, response, version) {
                                          request.get(`https://ipapi.co/${ip}/city`, function(err, response, city) {
                                              request.get(`https://ipapi.co/${ip}/region_code`, function(err, response, region_code) {
                                                  request.get(`https://ipapi.co/${ip}/country_code`, function(err, response, country_code) {
                                                      request.get(`https://ipapi.co/${ip}/country_code_iso3`, function(err, response, country_code_iso3) {
                                                          request.get(`https://ipapi.co/${ip}/country_tld`, function(err, response, country_tld) {
                                                              request.get(`https://ipapi.co/${ip}/continent_code`, function(err, response, continent_code) {
                                                                  request.get(`https://ipapi.co/${ip}/postal`, function(err, response, postal) {
                                                                      request.get(`https://ipapi.co/${ip}/latitude`, function(err, response, latitude) {
                                                                          request.get(`https://ipapi.co/${ip}/timezone`, function(err, response, timezone) {
                                                                              request.get(`https://ipapi.co/${ip}/currency_name`, function(err, response, currency_name) {
                                                                                  request.get(`https://ipapi.co/${ip}/languages`, function(err, response, languages) {
                                                                                      request.get(`https://ipapi.co/${ip}/country_population`, function(err, response, country_population) {
                                                                                          request.get(`https://ipapi.co/${ip}/country_area`, function(err, response, country_area) {
                                                                                              request.get(`https://ipapi.co/${ip}/longitude`, function(err, response, longitude) {
                                                                                                  console.log(`Region: ${region}\nTimeZone: ${timezone}\nCurrency: ${currency}\nCountry: ${country}\ncountry code: ${country_code}\nCountry code3: ${country_code_iso3}\nCountry LTD: ${country_tld}\nCont_Code: ${continent_code}\nPostal Code: ${postal}\nLatitude: ${latitude}\ntimezone: ${timezone}\ncurrency name: ${currency_name}\nlanguages: ${languages}\ncountry population: ${country_population}\ncountry area: ${country_area}\nlongitude: ${longitude}`);
                                                                                              });
                                                                                          });
                                                                                      });
                                                                                  });
                                                                              });
                                                                          });
                                                                      });
                                                                  });
                                                              });
                                                          });
                                                      });
                                                  });
                                              });
                                          });
                                      });
                                  });
                              });
                          });
                      });
                  });
              }
          });
        } else {
        if(NanyaDulu == "10") { // Server data reader by Galvin
          console.clear();
          let request = require('request');
const log4js = require('log4js')
const data = log4js.getLogger('data');
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

log4js.configure({
  appenders: {
    multi: { type: 'multiFile', base: 'logs/', property: 'categoryName', extension: '.html' }
  },
  categories: {
    default: { appenders: [ 'multi' ], level: 'debug' }
  }
});

console.log('Growtopia/serve_data.php reader coded by GalvinID credit to Clayne (C)')
readline.question('Target IP : ', ip => {
    request.post(`http://${ip}/growtopia/server_data.php`, function(err, response, body) {
    data.info(`${response && response.statusCode}\n${body}`)//saved in /logs (auto save)
	console.log(`${response && response.statusCode}\n${body}`)//will shown in terminal
	console.log('html/css copied successfully')
    readline.close();
  });
})
        } else {
      if(NanyaDulu == "8") {
        rl.question("What is Your Application ID for RPC : ", AppIDS => {
          rl.question("What is the Big Text To Your RPC (DETAIL) : ", TulisanGede => {
              rl.question("What is State For Your RPC : ", StatesNya => {
                  rl.question("What is Your Large Images Key? : ", LargeImageNya => {
                      rl.question("What is Your Large Image Text? : ", LImageText => {
      rl.question("Are You Want Your RPC With Buttons? (Y/N) : ", TanyaButton => {
          if(TanyaButton == "Y") {
      rl.question("How Much The Buttons? : (1/2) : ", BerapaBanyakButtonDia => {
          if(BerapaBanyakButtonDia == "1") {
      rl.question("What is The Buttons Text? : ", ButtonTextDia => {
          rl.question("The Buttons URL? : ", URLButtonDia => {
              const rpc = require('discord-rpc')
      const win = require('os')
      const rpct = new rpc.Client({transport: 'ipc'})
      const rpcid = "ID HERE" // rpc id
      const fs = require("fs");
      const moment = require("moment");
      const Date = moment(rpc.Client.balls).format('llll');
      // invtervals
      setInterval(function(){
          const d = Math.floor(win.uptime / 60 / 60 / 24);
          const h = Math.floor(win.uptime / 60 / 60 % 24);
          const m = Math.floor(win.uptime / 60 % 60);
      
      
          rpct.setActivity({
              details: `${TulisanGede}`,
              state: `${StatesNya}`,
              largeImageKey: `${LargeImageNya}`,
              largeImageText: `💾${LImageText}`, 
              buttons:
              [
                  { label: `${ButtonTextDia}`, url: `${URLButtonDia}` }
              ]
              },
      )}, 20000);
      
      console.log("RPC Setted Up!");
      rpct.login({clientId: AppIDS})
          })
      })    
      
          } else {
          const rpc = require('discord-rpc')
          const win = require('os')
          const rpct = new rpc.Client({transport: 'ipc'})
          const rpcid = "ID HERE" // GAUSAH DI ISI KONTOL
          const fs = require("fs");
          const moment = require("moment");
          const Date = moment(rpc.Client.balls).format('llll');
      if(BerapaBanyakButtonDia == "2") {
          setInterval(function(){
              const d = Math.floor(win.uptime / 60 / 60 / 24);
              const h = Math.floor(win.uptime / 60 / 60 % 24);
              const m = Math.floor(win.uptime / 60 % 60);
          
          
              rpct.setActivity({
                  details: `${TulisanGede}`,
                  state: `${StatesNya}`,
                  largeImageKey: `${LargeImageNya}`,
                  largeImageText: `💾${LImageText}`, 
                  buttons:
                  [
                      { label: `${ButtonTextDia}`, url: `${URLButtonDia}` },
                      { label: `${ButtonTextDia}`, url: `${URLButtonDia}` }
                  ]
                  },
          )}, 20000);
          
          console.log("RPC Setted Up!");
          rpct.login({clientId: AppIDS})
      }
          }
      })
          } else {
      if(TanyaButton == "N") {
          const rpc = require('discord-rpc')
          const win = require('os')
          const rpct = new rpc.Client({transport: 'ipc'})
          const rpcid = "ID HERE" // rpc id
          const fs = require("fs");
          const moment = require("moment");
          const Date = moment(rpc.Client.balls).format('llll');
          setInterval(function(){
              const d = Math.floor(win.uptime / 60 / 60 / 24);
              const h = Math.floor(win.uptime / 60 / 60 % 24);
              const m = Math.floor(win.uptime / 60 % 60);
          
          
              rpct.setActivity({
                  details: `${TulisanGede}`,
                  state: `${StatesNya}`,
                  largeImageKey: `${LargeImageNya}`,
                  largeImageText: `💾${LImageText}`, 
                  },
          )}, 20000);
          
          console.log("RPC Setted Up!");
          rpct.login({clientId: AppIDS})
      }
          }
      })
                      })
                  })
              })
          })
      })
      
      // Coded By github.com/FrenzY8
      // RPC Custom
      
      // console.log("RPC Setted Up!");
      } else {
      if(NanyaDulu == "6") { //by iMix
        console.log("Example : google.com".green)
        rl.question("Enter Websites Name with Domains : ", NAMAWeb => {
          if(NAMAWeb == "") {
            console.log("Cannot Blank!");
          } else {
            const dns = require('dns');
// dns.lookup() function searches
// for user IP address and family
// if there is no error
dns.lookup(NAMAWeb, // NAMAWeb = function from rl
(err, addresses, family, hostname) => {
    // Print the address found of user
    console.log('addresses:', addresses);
    // Print the family found of user  
//    console.log('family:', family);
console.log(Frenzy.blue)
    console.log(`${addresses} the IP from ${NAMAWeb}`)
//    console.log(hostname)
});
          }
        })
      } else {
        if(NanyaDulu == "7") { // base64
          rl.question("Enter Your Text to Decode/Encode : ", Tulisannya => {
            rl.question("Enter the Name for Files (Example : newtext) ", NamaFilenya => {
              /* rl.question("Enter The Formats Files : ", function(FormatFileNya) {
              } */
                rl.question("What is this? (decode) (encode) : ", MetodeDia => {
                    if (MetodeDia == "encode") {
                        // plain-text string
        const str = Tulisannya;
        // create a buffer
        const buff = Buffer.from(str, 'utf-8');
        // decode buffer as Base64
        const base64 = buff.toString('base64');
        // print Base64 string
        console.log(base64);
        fs.writeFileSync(
            `${NamaFilenya}.txt`,
            `${base64}`
        );
        const keypress = async () => {
            process.stdin.setRawMode(true)
            return new Promise(resolve => process.stdin.once('data', () => {
              process.stdin.setRawMode(false)
              resolve()
            }))
          }
          
          ;(async () => {
        
            console.log('program still running, press any key to continue')
            await keypress()
            console.log('bye')
          
          })().then(process.exit)
        
        // QmFzZTY0IEVuY29kaW5nIGluIE5vZGUuan
        
                    } else {
                        if (MetodeDia == "decode") {
                            const base64 = Tulisannya;
        
        // create a buffer
        const buff = Buffer.from(base64, 'base64');
        
        // decode buffer as UTF-8
        const str = buff.toString('utf-8');
        
        // print normal string
        console.log(str);
        fs.writeFileSync(
            `${NamaFilenya}`,
            `${str}`
        );
        const keypress = async () => {
            process.stdin.setRawMode(true)
            return new Promise(resolve => process.stdin.once('data', () => {
              process.stdin.setRawMode(false)
              resolve()
            }))
          }
          
          ;(async () => {
          
            console.log('Press Any Key To Next Files')
            await keypress()
            console.log('Decode Succes')
          
          })().then(process.exit)
        // Base64 Encoding in Node.js
                        }
                    }
                 // })
                })
            })
        });
        // footer
        // YANG CODE FRENZY ANJING
        } else {
        if(NanyaDulu == "2") {
            console.log("Now is Version : 1.1")
            const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('Any Key To Exits')
                await keypress()
              })().then(process.exit)
        } else {
            if(NanyaDulu == "3") {
                console.log("FrenzySG are Creator of this tools")
                const keypress = async () => {
                    process.stdin.setRawMode(true)
                    return new Promise(resolve => process.stdin.once('data', () => {
                      process.stdin.setRawMode(false)
                      resolve()
                    }))
                  }
                  
                  ;(async () => {
                  
                    console.log('Any Key To Exits')
                    await keypress()
                  })().then(process.exit)
            } else {
                if(NanyaDulu == "4") {
                    console.log("github.com/FrenzY8")
                    const keypress = async () => {
                        process.stdin.setRawMode(true)
                        return new Promise(resolve => process.stdin.once('data', () => {
                          process.stdin.setRawMode(false)
                          resolve()
                        }))
                      }
                      
                      ;(async () => {
                      
                        console.log('Any Key To Exits')
                        await keypress()
                      })().then(process.exit)
                } else {
                    if(NanyaDulu == "1") { // menu anti ddos hey kalian kontol
                      console.log(choose.green)
console.log(`
Wait...

[1] GTPS
[2] SAMP

Choose by number
Pilih dengan angka
`.blue)
rl.question("Which One Do You Wanna Execute? : ", MauGTPSAtauSAMP => {
  if(MauGTPSAtauSAMP == "2") {
    rl.question("Enter Your Ips : ", IPSAmp => {
      if(IPSAmp == "") {
        console.log("Cannot Blank"); // IP NYA HARS DI ISI LAH KONTOL PPK
      } else {
        console.clear();
        console.log("SA:MP Anti DoS is Under Progress!") // MAMPUS KENA TIPU YAHAHA
      }
    })
  } else {
    if(MauGTPSAtauSAMP == "1") { // GTPS PILIHAN DIA
// GTPS
console.log(Frenzy. blue)
console.log(`Today at : ${today}`)
console.log("Type 'C' to Close!".red)
rl.question("Enter A UserName : ".green, Username => {
    if(Username == Usernames) {
        console.log("> Correct Username!")
    } else {
        if(Username == "") {
            console.log(empty.blue)
            console.log("> Username Cannot Empty")
            const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('Any Key To Exits')
                await keypress()
              })().then(process.exit)
        } else {
        // process.exit();
        console.log("> Wrong Usernames")
        setTimeout(function () {
            console.log('> Wrongs!')
          }, 100)
          var end = Date.now() + 5000
          while (Date.now() < end) ;
          console.log('Will Be Closed Cause Wrong Passwords')
        const keypress = async () => {
            process.stdin.setRawMode(true)
            return new Promise(resolve => process.stdin.once('data', () => {
              process.stdin.setRawMode(false)
              resolve()
            }))
          }
          
          ;(async () => {
          
            console.log('Any Key To Exits')
            await keypress()
          })().then(process.exit)
        }
    }
    rl.question("Enter A Password : ".green, Password => {
        if(Password == Passwords) {
            console.log("> Correct Password");
            console.clear();
            // ACTIVITY SETUPS
// ACT 1 :
            console.log(setup.blue) // SETUP ASCII
    rl.question("Enter Your Ip : ".green, IPAddress => {
        if(IPAddress == "") {
            console.log(empty.blue)
            console.log("> Ip Address Cannot Empty")
            const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('Any Key To Exits')
                await keypress()
              })().then(process.exit)
        } else {
    rl.question("Enter Your Main Servers Port (17091) : ".green, MAINPort => {
        if(MAINPort == "") {
            console.log(empty.blue)
            console.log("> Port Cannot Empty")
            const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('Any Key To Exits')
                await keypress()
              })().then(process.exit)
        } else { 
    rl.question("Enter HTTP Port (80) : ".green, HTTP => {
        if(HTTP == "") {
            console.log(empty.blue)
            console.log("> HTTPS Cannot Blank!")
            const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('Any Key To Exits')
                await keypress()
              })().then(process.exit)
        } else {
          const choice = ['192.45.75.1', '198.33.09.389', '173.27.34.7'];
          const wut = Math.floor(Math.random() * choice.length);
console.log("IP : "+ choice[wut] +" Detected");
const http = require("http");
var blacklist = new Map();
var visit = 0;
// Coded by LyteVV on Github
const client = http.createServer(function(req, res) {
    let ipAddress = req.connection.remoteAddress;
    ipAddress = ipAddress.split(/::ffff:/g).filter(a => a).join('');
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop().trim() || 
        req.connection.remoteAddress || 
        req.socket.remoteAddress || 
        req.connection.socket.remoteAddress
        req.connection.destroy();
        
    if (req.url == "/growtopia/server_data.php") {
        if (req.method = "POST") {
            visit++;
            res.write(`server|${IPAddress}\nport|17091\ntype|1\n#maint|HTTP`);
            res.end();
            console.log(`==========[LOGS]==========\n[!] IP Address: ${ipAddress}\n[!] Req Method: ${req.method}\n[!] Entered Route: ${req.url}\n==========================`);
        }
    }

    else {
        res.writeHead(200);
        res.write(`<script>alert('PROTECT BY $yourname');</script><pre>Your ip (${ipAddress}) has been logged into >`);
        res.end();
        res.destroy();
    }
})

client.listen(80)
            const URL      = require('url');
const Promise  = require('bluebird');
const rp       = require('request-promise');
const extend   = require('extend');
const helpers  = require('./helpers');
// DELAY AMA REGE NYA DISINI YA KNTL
const DELAY = 5*1000;
const REGEXP = {
  jschl_vc : /name="jschl_vc" value="(\w+)"/,
  pass     : /name="pass" value="(.+?)"/,
  challenge: /setTimeout\(function\(\){\s+(var s,t,o,p,b,r,e,a,k,i,n,g,f.+?\r?\n[\s\S]+?a\.value =.+?)\r?\n/i,
  delay    : /setTimeout[\s\S]+f.submit\(\);\s*},\s*(\d+)\);/i
};
		// BIARIN YANG ADA DI BAWAH INI KENA BLOCK ASU
		
/*
const tape = require("tape");
const Ddos = require("./helpers");
const request = require("supertest-light");
const express = require("express");

// https://github.com/rook2pawn/node-ddos/issues/31

tape("localhost ", function(t) {
  t.plan(4);

  const ddos = new Ddos({ burst: 3, limit: 2 });
  t.equals("::ffff:127.0.0.1".match(ddos.ipv4re)[2], "127.0.0.1");
  t.equals("127.0.0.1".match(ddos.ipv4re)[2], "127.0.0.1");
  t.equals(`${IPAddress}:12568`.match(ddos.ipv4re)[2], "32.45.32.65:12568");

  const app = express();
  app.use(ddos.express);
  app.get("/user", (req, res) => {
    res.status(200).json({ name: "john" });
  });

  const doCall = function() {
    return request(app)
      .set("x-forwarded-for", "::1")
      .get("/user");
  };

  doCall()
    .then(() => {
      t.equals(
        Object.keys(ddos.table)[0].match(/127\.0\.0\.1/)[0],
        "127.0.0.1"
      );
    })
    .then(() => {
      ddos.end();
    });
}); */
/*
var http = require("http");
//var express = require("express");
var bodyParser = require("body-parser");
// var request = require("request");
// var Ddos = require("../");
// var ddos = new Ddos({ burst: 3, limit: 4, testmode: true });
var app = express();
app.use(ddos.express);
// app.use(bodyParser.json());
var server = http.createServer(app);

var QL = require("queuelib");
var q = new QL();

server.listen(5050);

var a = function(req, res, next) {
  next();
};
var b = function(req, res, next) {
  // some more random middleware
  next();
};
var c = function(req, res, next) {
  var num = req.body.num * 2;
  res.end(JSON.stringify({ foo: num }));
};
app.post("/article", a, b, c);

// var tape = require("tape");
tape("post test", function(t) {
  t.plan(11);
  q.series([
    function(lib) {
      request.post(
        { url: "http://localhost:5050/article", json: true, body: { num: 42 } },
        function(err, resp, body) {
          var key = Object.keys(ddos.table)[0];
          t.deepEqual(ddos.table[key], { count: 1, expiry: 1 });
          t.deepEqual(body, { foo: 84 });
          lib.done();
        }
      );
    },
    function(lib) {
      request.post(
        { url: "http://localhost:5050/article", json: true, body: { num: 42 } },
        function(err, resp, body) {
          var key = Object.keys(ddos.table)[0];
          t.deepEqual(ddos.table[key], { count: 2, expiry: 1 });
          t.deepEqual(body, { foo: 84 });
          lib.done();
        }
      );
    },
    function(lib) {
      request.post(
        { url: "http://localhost:5050/article", json: true, body: { num: 42 } },
        function(err, resp, body) {
          var key = Object.keys(ddos.table)[0];
          t.deepEqual(ddos.table[key], { count: 3, expiry: 1 });
          t.deepEqual(body, { foo: 84 });
          lib.done();
        }
      );
    },
    function(lib) {
      request.post(
        { url: "http://localhost:5050/article", json: true, body: { num: 42 } },
        function(err, resp, body) {
          var key = Object.keys(ddos.table)[0];
          t.deepEqual(ddos.table[key], { count: 4, expiry: 2 });
          t.deepEqual(body, { foo: 84 });
          lib.done();
        }
      );
    },
    function(lib) {
      request.post(
        { url: "http://localhost:5050/article", json: true, body: { num: 42 } },
        function(err, resp, body) {
          var key = Object.keys(ddos.table)[0];
          t.deepEqual(ddos.table[key], { count: 5, expiry: 4 });
          t.equal(resp.statusCode, 429, "should be 429");
          t.equal(body.count, 5, "should be 5");
          lib.done();
        }
      );
    },
    function(lib) {
      lib.done();
      t.end();
      server.close();
      ddos.stop();
    }
  ]);
}); */

const DEFAULT_USER_AGENTS = [
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36',
  'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0_4 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11B554a Safari/9537.53',
  'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:59.0) Gecko/20100101 Firefox/59.0',
  'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0'
];


function toLowerCaseObject(obj) {
  let res = obj;

  Object.keys(res).forEach(oldKey => {
    let newKey = oldKey.toLowerCase();
    // If newKey eql to oldKey so oldKey was lowercased
    if(newKey !== oldKey) {
      res[newKey] = res[oldKey];
      delete res[oldKey];
    } else {}
  });

  return res;
}

const lib = require("./lib");
const defaultParams = require("./lib/defaults");

const ddos = function(params) {
  if (!params) params = {};

  params = Object.assign({}, defaultParams(), params);
  params.maxcount = params.limit * 2;

  if (params.testmode) {
    console.log("ddos: starting params: ", params);
  }

  this.table = {};
  this.timer = setInterval(this.update.bind(this), params.checkinterval * 1000);
  this.express = this.handle.bind(this);
  this.middleware = this.handle.bind(this);
  this.params = params;
};
/*
===========================================================================================================

Thanks for Using Our Source AntiDoS
first you must know basic from this sources code before edited!
you can edit the username + password in config.json
but if you already build thats, you cant change the username and password anymore (need build again)

- This Sources Also Supported for SA:MP (Beta)
use main port 7777 if you're SA:MP
use main port 19071 if you're GTPS

thanks to :
- MGC
- MGV
- GrowTopiaNoobs
- ZxBoy
- iMix

This Source has 1000 lines!!
===========================================================================================================
*/
ddos.prototype.addWhitelist = lib.addWhitelist;
ddos.prototype.stop = lib.stop;
ddos.prototype.end = ddos.prototype.stop;
ddos.prototype.update = lib.update;
ddos.prototype.handle = lib.handle;
ddos.prototype.express = lib.handle;
ddos.prototype.koa = function() {
  return function(ctx, next) {
    var req = ctx.req;
    var res = ctx.res;

    return lib._handle(this.params,this.table, req)
    .then(() => {
      return next()
    })
  };
};

ddos.prototype.hapi17 = function (request, h) {
  const req = request.raw.req;
  const params = this.params;
  const table = this.table;


  return lib._handle(params, table, req)
  .then(() => {
    return h.continue
  })
  .catch((e) => {
    if (e.action === "respond") {
      const response = h.response(e.message);
      response.takeover();
      response.code(e.code);
      return response;
    }
  })


}
ddos.prototype.hapi = function(request, reply) {
  const req = request.raw.req;
  const res = reply;
  const table = this.table;
  const params = this.params;

  return lib._handle(params, table, req)
  .then(() => {
    return reply.continue();
  })
  .catch((e) => {
    if (e.action === "respond") {
      return res(e.message).code(e.code);
    }
  })

};
ddos.prototype.ipv4re = lib.ipv4re;

module.exports = exports = ddos;
class CloudflareBypasser {
  constructor(opts = {}) {
    this._delay     = opts.delay     || DELAY;
    this._headers   = toLowerCaseObject(opts.headers || {});
    this._userAgent = opts.userAgent || DEFAULT_USER_AGENTS[Math.floor(Math.random() * DEFAULT_USER_AGENTS.length)];
    this._jar       = opts.jar       || rp.jar();

    this._rp = rp.defaults({jar: this._jar});
  }

  get userAgent() {
    return this._userAgent;
  }

  get jar() {
    return this._jar;
  }

  request(uri, options) {
    let params = {
      headers: {},
      // TODO: delete this?
      // removeRefererHeader: false,
      // Set max redirects like at request
      maxRedirects       : 10,
      // Our redrects counter
      _redirectsCounter  : 0
    };

    if(typeof options === 'object') {
      extend(params, options, {uri: uri})
    }
    else if(typeof uri === 'string') {
      extend(params, {uri: uri});
    }
    else {
      extend(params, uri);
    }

    extend(params, {
      resolveWithFullResponse : true,
      simple                  : false,
      //We must do the redirects ourselves. Referrer is lost in the process
      followRedirect          : false,
    });

    // Headers to lowercase
    params.headers = extend({}, this._headers, toLowerCaseObject(params.headers));

    // Request node feature
    if(!params.uri && params.url) {
      params.uri = params.url;
      delete params.url;
    }

    // WHY? I dont know
    params.uri = URL.parse(params.uri);

    // User-Agent the most important header
    params.headers['user-agent'] = params.headers['user-agent'] || this._userAgent;

    // Show that we are moving from this site
    let referer = `${params.uri.protocol}//${params.uri.host}/`;
    params.headers['referer'] = params.headers['referer'] || referer;

    // Add param gzip if encoding include gzip
    if(typeof params.headers['accept-encoding'] === 'string' && params.headers['accept-encoding'].indexOf('gzip') !== -1) {
      params.gzip = true;
    }

    // Set cookies to jar and delete after
    if(typeof params.headers['cookie'] === 'string') {
      let cookies = params.headers['cookie'].split(';');
      cookies.forEach(cookie => {
        this.jar.setCookie(cookie, params.uri);
      });
      delete params.headers['cookie'];
    }

    return this._rp(params)
      .then(res => {
        // console.log(helpers.pretty(helpers.convertResponse(res)));
        let result = CloudflareBypasser.parse(res);
        // console.log();
        // console.log(helpers.pretty({parsed:result}));
        // console.log('\n\n\n\n\n\n\n\n\n\n\n\n');

        // Redirect
        if(result.redirect) {
          params._redirectsCounter++;
          let maxRedirects = parseInt(params.maxRedirects);
          if(
            !Number.isNaN(params._redirectsCounter) &&
            !Number.isNaN(maxRedirects) &&
            maxRedirects > 0 &&
            params._redirectsCounter >= maxRedirects
          ) {
            return Promise.reject(new Error('TOO_MUCH_REDIRECTS'));
          }

          params.uri = result.redirect;
          delete params.qs;
          delete params.url;
          return this.request(params);
        }

        // Error
        if(result.error) {
          throw new Error('ERROR:' + result.error);
        }

        // Captcha
        // TODO: add captcha solver
        if(result.captcha) {
          throw new Error('CAPTCHA');
        }

        // Challenge
        if(result.challenge) {
          let url = `${res.request.uri.protocol}//${res.request.uri.host}/cdn-cgi/l/chk_jschl`;

          let qs = {
            jschl_vc: result.challenge.jschl_vc,
            pass: result.challenge.pass,
            jschl_answer: result.challenge.resolved
          };

          params.headers['referer'] = res.request.uri.href;
          params.uri = URL.parse(url);
          params.qs = qs;

          return Promise.delay(this._delay).then(_ => {
            return this.request(params);
          });
        }

        return res;
      })
      ;
  }

  static parse(response = {}) {
    let body = response.body;
    let uri = response.request.uri;

    let result = {
      status   : response.statusCode,
      redirect : null,
      error    : null,
      captcha  : null,
      challenge: null
    }

    result.redirect = this.findRedirect(response);
    if(result.redirect) return result;

    result.error = this.findError(body);
    if(result.error) return result;

    result.captcha = this.findCaptcha(body);
    if(result.captcha) return result;

    result.challenge = this.findChallenge(body, uri.host);
    if(result.challenge) {
      result.challenge.resolved = this.solveChallenge(result.challenge.challenge);
    }

    return result;
  }

  static findRedirect(response = {}) {
    let uri = response.request.uri;

    if(response.headers && typeof response.headers.location === 'string') {
      // If server return redirect to abs link with host 'site.com/asdasd'
      let url = URL.parse(response.headers.location);
      if(url.host) {
        return response.headers.location;
      }
      // If server return redirect to abs link without host '/asdasd'
      // so we have to fill necessary parts
      return `${uri.protocol}://${uri.host}${response.headers.location}`
    }
    return false;
  }

  static findError(text = '') {
    // Trying to find '<span class="cf-error-code">1006</span>'
    let match = text.match(/<\w+\s+class="cf-error-code">(.*)<\/\w+>/i);
    if(match) {
      return parseInt(match[1]);
    }
    return false;
  }

  static findCaptcha(text = '') {
    return (text.indexOf('why_captcha') !== -1 || text.indexOf('g-recaptcha') !== -1);
  }

  // TODO:
  static solveCaptcha(data = {}) {
    return null;
  }

  static findChallenge(text = '', domain = '') {
    // jschl_vc
    let jschl_vc = text.match(REGEXP.jschl_vc);
    jschl_vc = jschl_vc ? jschl_vc[1] : null;

    // pass
    let pass = text.match(REGEXP.pass);
    pass = pass ? pass[1] : null;

    // delay
    let delay = text.match(REGEXP.delay);
    delay = delay ? delay[1] : null;

    // challange
    let challenge = text.match(REGEXP.challenge);
    if(challenge) {
      challenge = challenge[1].replace(/a\.value = (.+ \+ t\.length).+/i, '$1') // delete `a.value = .`
                              .replace(/\s{3,}[a-z](?: = |\.).+/g, '') // delete all `t = document.createElement...`
                              .replace('t.length', '' + domain.length) // replace t.length with domain length
                              .replace(/'; \d+'/g, '')
                              .replace(/[\n\\']/g, '')
      ;

      if(challenge.indexOf('toFixed') === -1) {
        throw new Error('ERROR:parsing challenge');
      }
    }
    else {
      challenge = null;
    }

    if(jschl_vc && pass && challenge) {
      return {
        jschl_vc : jschl_vc,
        pass     : pass,
        challenge: challenge,
        delay    : parseFloat(delay)
      };
    } else {
      return null;
    }
  }

  static solveChallenge(code = '') {
    return eval(code);
  }

}
            var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
                if (k2 === undefined) k2 = k;
                Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
            }) : (function(o, m, k, k2) {
                if (k2 === undefined) k2 = k;
                o[k2] = m[k];
            }));
            var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
                Object.defineProperty(o, "default", { enumerable: true, value: v });
            }) : function(o, v) {
                o["default"] = v;
            });
            var __importStar = (this && this.__importStar) || function (mod) {
                if (mod && mod.__esModule) return mod;
                var result = {};
                if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
                __setModuleDefault(result, mod);
                return result;
            };
            Object.defineProperty(exports, "__esModule", { value: true });
            var blacklist = new Map();
            var packet = `server|${IPAddress}\nport|17091\ntype|1\n#maint|Mainetrance message (Not used for now) -- NodeJS-GTPS\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001`;
            var server = http.createServer(function (req, res) {
                if (req.url === "/growtopia/server_data.php" && req.method.toLowerCase() === "post") {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.write(packet, function (err) {
                        if (err)
                            console.log(err);
                    });
                    res.end();
                    res.destroy();
                }
                else
                    res.destroy();
            });
/*            server.listen(80);
            function add_address(address) {
                blacklist.set(address, Date.now() + 5000);
            } */
            server.on("connection", function (socket) {
                if (!blacklist.has(socket.remoteAddress)) {
                    add_address(socket.remoteAddress);
                }
                else {
                    var not_allowed = blacklist.get(socket.remoteAddress);
                    if (Date.now() > not_allowed) {
                        blacklist.delete(socket.remoteAddress);
                    }
                    else
                        socket.destroy();
                }
            });
var packet = `server|${IPAddress}\nport|17091\ntype|1\n#maint|Mainetrance message (Not used for now) -- NodeJS-GTPS\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001`;
//var http = require('http'); 
var timeout = 5000;
var server = http.createServer(function (req, res) {  
			var RateLimiter = require('limiter').RateLimiter;
         
            var limiter = new RateLimiter(150, 'hour');
            limiter.removeTokens(1, function(err, remainingRequests) {
            
            });
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(1, 250);
            
            limiter.removeTokens(1, function() {
            });
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(150, 'hour', true);  
            limiter.removeTokens(1, function(err, remainingRequests) {
            if (remainingRequests < 0) {
            response.writeHead(200, {'Content-Type': 'text/html;charset=UTF-8'});
            response.end('200 Too Many Requests - your IP is being rate limited');
            } 
            });
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(10, 'second');
            
            if (limiter.tryRemoveTokens(5))
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(1, 250);
            
            limiter.getTokensRemaining();
            var BURST_RATE = 1024 * 1024 * 150; 
            var FILL_RATE = 1024 * 1024 * 50; 
            var TokenBucket = require('limiter').TokenBucket;
            var bucket = new TokenBucket(BURST_RATE, FILL_RATE, 'second', null); 
    // const { UserNames, Passwords } = require('./config.json');
    if (req.url == "/growtopia/server_data.php") {
		var ip = (req.headers['x-forwarded-for'] || '').split(',').pop().trim() || 
        req.connection.remoteAddress || 
        req.socket.remoteAddress || 
        req.connection.socket.remoteAddress
        if(req.method === "POST") {
		console.log(`[Growtopia Logs] ${req.connection.remoteAddress} successfully entered to the connection!`)
		}
		if(req.method === "GET") {
		console.log(`[Request Log] ${req.connection.remoteAddress} blocked from request`)
		req.connection.destroy();
		}
        
        res.write('server|149.28.134.159\nport|17091\ntype|1\n#maint|Maintenance\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001');
}
else
res.writeHead(200, { "Content-Type": "text/html" });
res.write("hello", function (err) {
	if (err) 
	console.log(err);
	setTimeout(function () { req.connection.destroy(); }, 500);
	res.writeHead(200, { "Content-Type": "text/html" });
	res.writeHead(200, { "Content-Type": "text/html" });
res.write("hello", function (err) {
	if (err) 
	console.log(err);
	process.env.BLACKLIST
	res.end();
	res.destroy();
	});
	});
});
server.listen(80);
            var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
                if (k2 === undefined) k2 = k;
                Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
            }) : (function(o, m, k, k2) {
                if (k2 === undefined) k2 = k;
                o[k2] = m[k];
            }));
            var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
                Object.defineProperty(o, "default", { enumerable: true, value: v });
            }) : function(o, v) {
                o["default"] = v;
            });
            var __importStar = (this && this.__importStar) || function (mod) {
                if (mod && mod.__esModule) return mod;
                var result = {};
                if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
                __setModuleDefault(result, mod);
                return result;
            };
            Object.defineProperty(exports, "__esModule", { value: true });
           // var http = __importStar(require("http"));
            var blacklist = new Map();
            var packet = `server|${IPAddress}\nport|${MAINPort}\ntype|1\n#maint|Mainetrance message (Not used for now) -- NodeJS-GTPS\n\nbeta_server|${IPAddress}\nbeta_port|${MAINPort}\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001`;
            var server = http.createServer(function (req, res) {
                if (req.url === "/growtopia/server_data.php" && req.method.toLowerCase() === "post") {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.write(packet, function (err) {
                        if (err)
                            console.log(`BAD PORT!`);
                    });
                    res.end();
                    res.destroy();
                }
                else
                    res.destroy();
            });
            /* server.listen(80);
            function add_address(address) {
                blacklist.set(address, Date.now() + 5000);
            } */
            server.on("connection", function (socket) {
                if (!blacklist.has(socket.remoteAddress)) {
                    add_address(socket.remoteAddress);
                }
                else {
                    var not_allowed = blacklist.get(socket.remoteAddress);
                    if (Date.now() > not_allowed) {
                        blacklist.delete(socket.remoteAddress);
                    }
                    else
                        socket.destroy();
                }
            });
            console.clear();
          //  console.log(listen.green)
          console.log(listen.yellow)
            console.log(`Nub Server ${IPAddress} has been Setted`.blue)
            console.log(`${MAINPort} , ${HTTP} has been Protected!`.green)
            const keypress = async () => {
                process.stdin.setRawMode(true)
                return new Promise(resolve => process.stdin.once('data', () => {
                  process.stdin.setRawMode(false)
                  resolve()
                }))
              }
              
              ;(async () => {
              
                console.log('You Can End This Program by Click Any Key!')
                await keypress()
		      
		  // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"    
rl.question("Sure Want to Exit? Anti DDoS Maybe will terminated. (Y/N) : ", YakinGak => {
    setTimeout(function () {
        console.log('> If you didnt reply anything the exe will be closed..')
      }, 100)
      var end = Date.now() + 5000
      while (Date.now() < end) ;
      console.log('TIMEOUT! CLOSED!')
    if(YakinGak == "Y") {
        process.exit();
    } else {
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    // KITA BAKAL ULANG CODE YANG DI ATAS JIKA ORANG INI KETIK "N"   
	    
       //  var prompt = require('prompt-sync')();
var packet = "server|\nport|17091\ntype|1\n#maint|Mainetrance message (Not used for now) -- NodeJS-GTPS\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001";
var http = require('http'); 
var timeout = 5000;
var server = http.createServer(function (req, res) {  
			var RateLimiter = require('limiter').RateLimiter;
         
            var limiter = new RateLimiter(150, 'hour');
            limiter.removeTokens(1, function(err, remainingRequests) {
            
            });
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(1, 250);
            
            limiter.removeTokens(1, function() {
            });
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(150, 'hour', true);  
            limiter.removeTokens(1, function(err, remainingRequests) {
            if (remainingRequests < 0) {
            response.writeHead(200, {'Content-Type': 'text/html;charset=UTF-8'});
            response.end('200 Too Many Requests - your IP is being rate limited');
            } 
            });
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(10, 'second');
            
            if (limiter.tryRemoveTokens(5))
            var RateLimiter = require('limiter').RateLimiter;
            var limiter = new RateLimiter(1, 250);
            
            limiter.getTokensRemaining();
            var BURST_RATE = 1024 * 1024 * 150; 
            var FILL_RATE = 1024 * 1024 * 50; 
            var TokenBucket = require('limiter').TokenBucket;
            var bucket = new TokenBucket(BURST_RATE, FILL_RATE, 'second', null); 
    
    if (req.url == "/growtopia/server_data.php") {
		var ip = (req.headers['x-forwarded-for'] || '').split(',').pop().trim() || 
        req.connection.remoteAddress || 
        req.socket.remoteAddress || 
        req.connection.socket.remoteAddress
        if(req.method === "POST") {
		console.log(`[Growtopia Logs] ${req.connection.remoteAddress} successfully entered to the connection!`)
		}
		if(req.method === "GET") {
		console.log(`[Request Log] ${req.connection.remoteAddress} blocked from request`)
		req.connection.destroy();
		}
        
        res.write('server|149.28.134.159\nport|17091\ntype|1\n#maint|Maintenance\n\nbeta_server|127.0.0.1\nbeta_port|17091\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001');
}
else
res.writeHead(200, { "Content-Type": "text/html" });
res.write("hello", function (err) {
	if (err) 
	console.log(err);
	setTimeout(function () { req.connection.destroy(); }, 500);
	res.writeHead(200, { "Content-Type": "text/html" });
	res.writeHead(200, { "Content-Type": "text/html" });
res.write("hello", function (err) {
	if (err) 
	console.log(err);
	process.env.BLACKLIST
	res.end();
	res.destroy();
	});
	});
});
server.listen(80); 
        var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
            if (k2 === undefined) k2 = k;
            Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
        }) : (function(o, m, k, k2) {
            if (k2 === undefined) k2 = k;
            o[k2] = m[k];
        }));
        var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
            Object.defineProperty(o, "default", { enumerable: true, value: v });
        }) : function(o, v) {
            o["default"] = v;
        });
        var __importStar = (this && this.__importStar) || function (mod) {
            if (mod && mod.__esModule) return mod;
            var result = {};
            if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
            __setModuleDefault(result, mod);
            return result;
        };
        Object.defineProperty(exports, "__esModule", { value: true });
        var http = __importStar(require("http"));
        var blacklist = new Map();
        var packet = `server|${IPAddress}\nport|${MAINPort}\ntype|1\n#maint|Mainetrance message (Not used for now) -- NodeJS-GTPS\n\nbeta_server|${IPAddress}\nbeta_port|${MAINPort}\n\nbeta_type|1\nmeta|localhost\nRTENDMARKERBS1001`;
        var server = http.createServer(function (req, res) {
            if (req.url === "/growtopia/server_data.php" && req.method.toLowerCase() === "post") {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.write(packet, function (err) {
                    if (err)
                        console.log(`BAD PORT!`);
                });
                res.end();
                res.destroy();
            }
            else
                res.destroy();
        });
        /* server.listen(80);
        function add_address(address) {
            blacklist.set(address, Date.now() + 5000);
        } */
        const URL      = require('url');
const Promise  = require('bluebird');
const rp       = require('request-promise');
const extend   = require('extend');
const helpers  = require('./helpers');

const DELAY = 5*1000;

const REGEXP = {
  jschl_vc : /name="jschl_vc" value="(\w+)"/,
  pass     : /name="pass" value="(.+?)"/,
  challenge: /setTimeout\(function\(\){\s+(var s,t,o,p,b,r,e,a,k,i,n,g,f.+?\r?\n[\s\S]+?a\.value =.+?)\r?\n/i,
  delay    : /setTimeout[\s\S]+f.submit\(\);\s*},\s*(\d+)\);/i
};

const DEFAULT_USER_AGENTS = [
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36',
  'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0_4 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11B554a Safari/9537.53',
  'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:59.0) Gecko/20100101 Firefox/59.0',
  'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0'
];


function toLowerCaseObject(obj) {
  let res = obj;

  Object.keys(res).forEach(oldKey => {
    let newKey = oldKey.toLowerCase();
    // If newKey eql to oldKey so oldKey was lowercased
    if(newKey !== oldKey) {
      res[newKey] = res[oldKey];
      delete res[oldKey];
    } else {}
  });

  return res;
}

class CloudflareBypasser {
  constructor(opts = {}) {
    this._delay     = opts.delay     || DELAY;
    this._headers   = toLowerCaseObject(opts.headers || {});
    this._userAgent = opts.userAgent || DEFAULT_USER_AGENTS[Math.floor(Math.random() * DEFAULT_USER_AGENTS.length)];
    this._jar       = opts.jar       || rp.jar();

    this._rp = rp.defaults({jar: this._jar});
  }

  get userAgent() {
    return this._userAgent;
  }

  get jar() {
    return this._jar;
  }

  request(uri, options) {
    let params = {
      headers: {},
      // TODO: delete this?
      // removeRefererHeader: false,
      // Set max redirects like at request
      maxRedirects       : 10,
      // Our redrects counter
      _redirectsCounter  : 0
    };

    if(typeof options === 'object') {
      extend(params, options, {uri: uri})
    }
    else if(typeof uri === 'string') {
      extend(params, {uri: uri});
    }
    else {
      extend(params, uri);
    }

    extend(params, {
      resolveWithFullResponse : true,
      simple                  : false,
      //We must do the redirects ourselves. Referrer is lost in the process
      followRedirect          : false,
    });

    // Headers to lowercase
    params.headers = extend({}, this._headers, toLowerCaseObject(params.headers));

    // Request node feature
    if(!params.uri && params.url) {
      params.uri = params.url;
      delete params.url;
    }

    // WHY? I dont know
    params.uri = URL.parse(params.uri);

    // User-Agent the most important header
    params.headers['user-agent'] = params.headers['user-agent'] || this._userAgent;

    // Show that we are moving from this site
    let referer = `${params.uri.protocol}//${params.uri.host}/`;
    params.headers['referer'] = params.headers['referer'] || referer;

    // Add param gzip if encoding include gzip
    if(typeof params.headers['accept-encoding'] === 'string' && params.headers['accept-encoding'].indexOf('gzip') !== -1) {
      params.gzip = true;
    }

    // Set cookies to jar and delete after
    if(typeof params.headers['cookie'] === 'string') {
      let cookies = params.headers['cookie'].split(';');
      cookies.forEach(cookie => {
        this.jar.setCookie(cookie, params.uri);
      });
      delete params.headers['cookie'];
    }

    return this._rp(params)
      .then(res => {
        // console.log(helpers.pretty(helpers.convertResponse(res)));
        let result = CloudflareBypasser.parse(res);
        // console.log();
        // console.log(helpers.pretty({parsed:result}));
        // console.log('\n\n\n\n\n\n\n\n\n\n\n\n');

        // Redirect
        if(result.redirect) {
          params._redirectsCounter++;
          let maxRedirects = parseInt(params.maxRedirects);
          if(
            !Number.isNaN(params._redirectsCounter) &&
            !Number.isNaN(maxRedirects) &&
            maxRedirects > 0 &&
            params._redirectsCounter >= maxRedirects
          ) {
            return Promise.reject(new Error('TOO_MUCH_REDIRECTS'));
          }

          params.uri = result.redirect;
          delete params.qs;
          delete params.url;
          return this.request(params);
        }

        // Error
        if(result.error) {
          throw new Error('ERROR:' + result.error);
        }

        // Captcha
        // TODO: add captcha solver
        if(result.captcha) {
          throw new Error('CAPTCHA');
        }

        // Challenge
        if(result.challenge) {
          let url = `${res.request.uri.protocol}//${res.request.uri.host}/cdn-cgi/l/chk_jschl`;

          let qs = {
            jschl_vc: result.challenge.jschl_vc,
            pass: result.challenge.pass,
            jschl_answer: result.challenge.resolved
          };

          params.headers['referer'] = res.request.uri.href;
          params.uri = URL.parse(url);
          params.qs = qs;

          return Promise.delay(this._delay).then(_ => {
            return this.request(params);
          });
        }

        return res;
      })
      ;
  }

  static parse(response = {}) {
    let body = response.body;
    let uri = response.request.uri;

    let result = {
      status   : response.statusCode,
      redirect : null,
      error    : null,
      captcha  : null,
      challenge: null
    }

    result.redirect = this.findRedirect(response);
    if(result.redirect) return result;

    result.error = this.findError(body);
    if(result.error) return result;

    result.captcha = this.findCaptcha(body);
    if(result.captcha) return result;

    result.challenge = this.findChallenge(body, uri.host);
    if(result.challenge) {
      result.challenge.resolved = this.solveChallenge(result.challenge.challenge);
    }

    return result;
  }

  static findRedirect(response = {}) {
    let uri = response.request.uri;

    if(response.headers && typeof response.headers.location === 'string') {
      // If server return redirect to abs link with host 'site.com/asdasd'
      let url = URL.parse(response.headers.location);
      if(url.host) {
        return response.headers.location;
      }
      // If server return redirect to abs link without host '/asdasd'
      // so we have to fill necessary parts
      return `${uri.protocol}://${uri.host}${response.headers.location}`
    }
    return false;
  }

  static findError(text = '') {
    // Trying to find '<span class="cf-error-code">1006</span>'
    let match = text.match(/<\w+\s+class="cf-error-code">(.*)<\/\w+>/i);
    if(match) {
      return parseInt(match[1]);
    }
    return false;
  }

  static findCaptcha(text = '') {
    return (text.indexOf('why_captcha') !== -1 || text.indexOf('g-recaptcha') !== -1);
  }

  // TODO:
  static solveCaptcha(data = {}) {
    return null;
  }

  static findChallenge(text = '', domain = '') {
    // jschl_vc
    let jschl_vc = text.match(REGEXP.jschl_vc);
    jschl_vc = jschl_vc ? jschl_vc[1] : null;

    // pass
    let pass = text.match(REGEXP.pass);
    pass = pass ? pass[1] : null;

    // delay
    let delay = text.match(REGEXP.delay);
    delay = delay ? delay[1] : null;

    // challange
    let challenge = text.match(REGEXP.challenge);
    if(challenge) {
      challenge = challenge[1].replace(/a\.value = (.+ \+ t\.length).+/i, '$1') // delete `a.value = .`
                              .replace(/\s{3,}[a-z](?: = |\.).+/g, '') // delete all `t = document.createElement...`
                              .replace('t.length', '' + domain.length) // replace t.length with domain length
                              .replace(/'; \d+'/g, '')
                              .replace(/[\n\\']/g, '')
      ;

      if(challenge.indexOf('toFixed') === -1) {
        throw new Error('ERROR:parsing challenge');
      }
    }
    else {
      challenge = null;
    }

    if(jschl_vc && pass && challenge) {
      return {
        jschl_vc : jschl_vc,
        pass     : pass,
        challenge: challenge,
        delay    : parseFloat(delay)
      };
    } else {
      return null;
    }
  }

  static solveChallenge(code = '') {
    return eval(code);
  }

}
        server.on("connection", function (socket) {
            if (!blacklist.has(socket.remoteAddress)) {
                add_address(socket.remoteAddress);
            }
            else {
                var not_allowed = blacklist.get(socket.remoteAddress);
                if (Date.now() > not_allowed) {
                    blacklist.delete(socket.remoteAddress);
                }
                else
                    socket.destroy();
            }
        });
        console.clear();
      //  console.log(listen.green)
      console.log(listen.yellow)
      console.log("Exit Cancelled".red)
        console.log(`Nub Server ${IPAddress} has been Setted`.blue)
        console.log(`${MAINPort} , ${HTTP} has been Protected!`.green)
        console.log("server_data_FrenzySG.php has been Created in ('C://xampp//htdocs//growtopia')")
        fs.writeFileSync
        "C://xampp//htdocs//growtopia//server_data.php"
        "By FrenzySG"
    }
})
              })().then(console.log("FrenzySG#6346".green))
            // server.on("listening", function () { return console.log(`${MAINPort} Has been Protected with HTTPS ${HTTP}`); });
        }
    })
        }
    })
        }
    })
        } else {
            console.log("Wrong Passwords!")
            setTimeout(function () {
                console.log('> Wrongs!')
              }, 100)
              var end = Date.now() + 5000
              while (Date.now() < end) ;
              console.log('Will Be Closed Cause Wrong Passwords')
              
        }
        // JANGAN DI APUS OKE MEK
    }) // DIBAWAH INI CUMAN PAGER ANJING
})
}
}
})
}
                }
}
}
}
}
      }
}
}
} // else {}
}
}
}
}
}
}
        }
}
}
        }
}
        }
}
      }
}
})
/*
===========================================================================================================

Thanks for Using Our Source AntiDoS
first you must know basic from this sources code before edited!
you can edit the username + password in config.json
but if you already build thats, you cant change the username and password anymore (need build again)

- This Sources Also Supported for SA:MP (Beta)
use main port 7777 if you're SA:MP
use main port 17091 if you're GTPS

thanks to :
- MGC
- MGV
- GrowTopiaNoobs
- ZxBoy
- iMix

This Source has 1000 lines!!
===========================================================================================================
*/
/*
AUTHOR : FrenzySG
*/
