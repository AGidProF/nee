## [Indonesia]
Anti ini sudah jadi (build) oleh FrenzySG jadi semisal kalian
mau edit/rename username dan password. kalian bisa lngsung ke github

## github.com/FrenzY8/gtos-antiddos
frenzyxteam.odoo.com

bebas rename asal jangan hapus LICENSE! karna itu bagian yang paling penting untuk kami!
hubungi via whatsapp jika ada maslah/crashed

wa.me/6283871151084
frenzyxteam.odoo.com

## - Karna kalian gabisa edit .exe nya jadi ini adalah username dan pass nya >
Usernames : Frenzy 
Password : 1812

## Ussrnames diawali dengan (F) besar
© Powered by FrenzYXTeam
- ANTIDDOS GTOS OPEN SOURCE GITHUB.COM/FRENZY8 -
